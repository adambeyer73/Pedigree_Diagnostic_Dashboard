package com.pedigreetechnologies.diagnosticview;

/**
 * Created by Joe on 2/26/2017.
 */

public interface IDataConnection {
    SensorMessage readMessage();
}
